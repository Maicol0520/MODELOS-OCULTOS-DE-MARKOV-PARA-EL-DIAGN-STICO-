"""
simulacion.py - Experimento factorial (F5).

Diseno: eps in {0.0, 0.3, 0.6} x T in {100, 500, 1000}  -> 9 escenarios
        30 replicas por escenario (semillas fijas via SeedSequence)
        10 inicializaciones Dirichlet de Baum-Welch por replica

Salidas (carpeta resultados/):
    replicas.csv        una fila por (escenario, replica)         -> 270 filas
    inicializaciones.csv una fila por (escenario, replica, init)   -> 2700 filas
Ejecutar:  python simulacion.py
"""
import os
import time

import numpy as np
import pandas as pd

from hmm import (A0, B0, PI0, HMM, ruido_B, inicializacion_dirichlet,
                 mejor_permutacion, exactitud)

SEED_GLOBAL = 2026
EPS_LIST = [0.0, 0.3, 0.6]
T_LIST = [100, 500, 1000]
N_REP = 30
N_INIT = 10
MAX_ITER, TOL = 200, 1e-6
SALIDA = "resultados"


def baseline_ingenuo(o):
    """Regla sin modelo: Baja->Normal, Media->Degradado, Alta->Falla."""
    return np.asarray(o).copy()


def una_replica(i_eps, eps, T, r):
    ss = np.random.SeedSequence([SEED_GLOBAL, i_eps, T, r])
    hijos = ss.spawn(1 + N_INIT)
    rng_datos = np.random.default_rng(hijos[0])

    B_eps = ruido_B(B0, eps)
    verdadero = HMM(A0, B_eps, PI0)
    q, o = verdadero.simular(T, rng_datos)

    # Referencias: Viterbi con el modelo verdadero (oraculo) y regla ingenua
    acc_oraculo = exactitud(q, verdadero.viterbi(o)[0])
    acc_ingenuo = exactitud(q, baseline_ingenuo(o))
    ll_verdadero = verdadero.loglik(o)

    filas_init = []
    for k in range(N_INIT):
        rng_i = np.random.default_rng(hijos[1 + k])
        A_i, B_i, pi_i = inicializacion_dirichlet(3, 3, rng_i)
        m = HMM(A_i, B_i, pi_i)
        info = m.baum_welch(o, max_iter=MAX_ITER, tol=TOL)
        p = mejor_permutacion(m.A, m.B, A0, B_eps)
        # reordenar modelo aprendido a la convencion de estados del modelo real
        m_ord = HMM(m.A[np.ix_(p, p)], m.B[p], m.pi[p])
        path = m_ord.viterbi(o)[0]
        filas_init.append(dict(
            i_eps=i_eps, eps=eps, T=T, rep=r, init=k,
            loglik=m.loglik(o), iter=info["iter"], convergio=info["convergio"],
            acc_bw=exactitud(q, path),
            err_A=np.linalg.norm(m_ord.A - A0),
            err_B=np.linalg.norm(m_ord.B - B_eps),
        ))
    df_i = pd.DataFrame(filas_init)

    # Mejor inicializacion = mayor log-verosimilitud (criterio no supervisado)
    mejor = df_i.loc[df_i["loglik"].idxmax()]
    cerca = (df_i["loglik"] >= mejor["loglik"] - 1e-2)
    fila = dict(
        i_eps=i_eps, eps=eps, T=T, rep=r,
        acc_oraculo=acc_oraculo, acc_ingenuo=acc_ingenuo,
        ll_verdadero=ll_verdadero,
        ll_mejor=mejor["loglik"],
        acc_bw=mejor["acc_bw"], err_A=mejor["err_A"], err_B=mejor["err_B"],
        iter_mejor=mejor["iter"],
        iter_media=df_i["iter"].mean(),
        frac_convergio=df_i["convergio"].mean(),
        frac_optimo=cerca.mean(),            # inits que alcanzan el mejor optimo
        sd_loglik_inits=df_i["loglik"].std(ddof=1),
        sd_acc_inits=df_i["acc_bw"].std(ddof=1),
        n_optimos_distintos=df_i["loglik"].round(1).nunique(),
    )
    return fila, df_i


def main():
    os.makedirs(SALIDA, exist_ok=True)
    filas, inits = [], []
    hechos = set()
    if os.path.exists(f"{SALIDA}/replicas.csv"):          # reanudar si hay avance
        prev = pd.read_csv(f"{SALIDA}/replicas.csv")
        filas = prev.to_dict("records")
        inits = [pd.read_csv(f"{SALIDA}/inicializaciones.csv")]
        hechos = set(zip(prev["eps"], prev["T"]))
    t0 = time.time()
    total = len(EPS_LIST) * len(T_LIST) * N_REP
    for i_eps, eps in enumerate(EPS_LIST):
        for T in T_LIST:
            if (eps, T) in hechos:
                continue
            for r in range(N_REP):
                f, d = una_replica(i_eps, eps, T, r)
                filas.append(f)
                inits.append(d)
            print(f"[{len(filas)}/{total}] eps={eps} T={T} listo | {time.time() - t0:.0f}s", flush=True)
            pd.DataFrame(filas).to_csv(f"{SALIDA}/replicas.csv", index=False)
            pd.concat(inits).to_csv(f"{SALIDA}/inicializaciones.csv", index=False)
    print("FIN", f"{time.time() - t0:.0f}s", flush=True)


if __name__ == "__main__":
    main()
