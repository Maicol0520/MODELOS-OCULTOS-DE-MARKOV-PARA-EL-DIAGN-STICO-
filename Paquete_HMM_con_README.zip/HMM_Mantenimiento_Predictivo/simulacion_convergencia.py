"""
simulacion_convergencia.py - Control de convergencia (subconjunto del diseno).
T = 1000, eps in {0, 0.3, 0.6}, replicas 0-9 (mismas semillas que simulacion.py),
10 inicializaciones, max_iter = 1000 (frente a 200 en el diseno principal).
Salidas: resultados/convergencia_replicas.csv, convergencia_inicializaciones.csv
Ejecutar: python simulacion_convergencia.py   (reanudable por eps)
"""
import os, time
import pandas as pd
import simulacion as S

S.MAX_ITER = 1000
T, N_REP_SUB = 1000, 10
R = S.SALIDA
f_rep, f_ini = f"{R}/convergencia_replicas.csv", f"{R}/convergencia_inicializaciones.csv"

filas, inits, hechos = [], [], set()
if os.path.exists(f_rep):
    prev = pd.read_csv(f_rep)
    filas, inits = prev.to_dict("records"), [pd.read_csv(f_ini)]
    hechos = set(prev["eps"])
t0 = time.time()
for i_eps, eps in enumerate(S.EPS_LIST):
    if eps in hechos:
        continue
    for r in range(N_REP_SUB):
        f, d = S.una_replica(i_eps, eps, T, r)
        filas.append(f); inits.append(d)
    pd.DataFrame(filas).to_csv(f_rep, index=False)
    pd.concat(inits).to_csv(f_ini, index=False)
    print(f"eps={eps} listo | {time.time()-t0:.0f}s", flush=True)
print("FIN", flush=True)
