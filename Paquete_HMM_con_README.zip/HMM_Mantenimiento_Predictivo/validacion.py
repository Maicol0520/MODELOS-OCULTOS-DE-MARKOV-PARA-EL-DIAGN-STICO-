"""
validacion.py - Verifica la implementacion propia:
  V1. Distribucion estacionaria y tiempos de permanencia (analitico vs simulado).
  V2. Forward == fuerza bruta (T pequeno).
  V3. Forward / Viterbi / Baum-Welch vs hmmlearn.
Ejecutar:  python validacion.py
"""
import itertools
import warnings

import numpy as np
from hmmlearn.hmm import CategoricalHMM

from hmm import (A0, B0, PI0, HMM, distribucion_estacionaria,
                 inicializacion_dirichlet, mejor_permutacion)

warnings.filterwarnings("ignore")
SEED = 2026
rng = np.random.default_rng(SEED)
modelo = HMM(A0, B0, PI0)

print("=" * 60)
print("V1. Verificacion analitica vs simulacion")
print("=" * 60)
pi_est = distribucion_estacionaria(A0)
q, o = modelo.simular(200_000, rng)
freq = np.bincount(q, minlength=3) / len(q)
print("pi* analitica :", np.round(pi_est, 4))
print("frec. simulada:", np.round(freq, 4))

# tiempos de permanencia (longitud de rachas completas)
rachas = {0: [], 1: [], 2: []}
inicio = 0
for t in range(1, len(q) + 1):
    if t == len(q) or q[t] != q[inicio]:
        if inicio > 0 and t < len(q):          # solo rachas completas
            rachas[q[inicio]].append(t - inicio)
        inicio = t
for i, nombre in enumerate(["Normal", "Degradado", "Falla"]):
    print(f"Permanencia {nombre:9s}: teorica {1 / (1 - A0[i, i]):5.2f} | simulada {np.mean(rachas[i]):5.2f}")

print("\n" + "=" * 60)
print("V2. Forward vs fuerza bruta (T = 6)")
print("=" * 60)
obs_c = modelo.simular(6, rng)[1]
p_bruta = 0.0
for ruta in itertools.product(range(3), repeat=6):
    p = PI0[ruta[0]] * B0[ruta[0], obs_c[0]]
    for t in range(1, 6):
        p *= A0[ruta[t - 1], ruta[t]] * B0[ruta[t], obs_c[t]]
    p_bruta += p
print(f"log P(O|lambda) fuerza bruta: {np.log(p_bruta):.10f}")
print(f"log P(O|lambda) forward     : {modelo.loglik(obs_c):.10f}")

print("\n" + "=" * 60)
print("V3. Comparacion con hmmlearn (T = 1000)")
print("=" * 60)
q, o = modelo.simular(1000, rng)
ref = CategoricalHMM(n_components=3)
ref.startprob_, ref.transmat_, ref.emissionprob_ = PI0.copy(), A0.copy(), B0.copy()
ll_ref = ref.score(o.reshape(-1, 1))
ll_own = modelo.loglik(o)
path_ref = ref.predict(o.reshape(-1, 1))
path_own, _ = modelo.viterbi(o)
print(f"Forward   : propio {ll_own:.8f} | hmmlearn {ll_ref:.8f} | dif {abs(ll_own - ll_ref):.2e}")
print(f"Viterbi   : coincidencia de rutas = {np.mean(path_ref == path_own):.4f}")

# Baum-Welch: misma inicializacion en ambas implementaciones
A_i, B_i, pi_i = inicializacion_dirichlet(3, 3, np.random.default_rng(7))
propio = HMM(A_i, B_i, pi_i)
info = propio.baum_welch(o, max_iter=500, tol=1e-9)
lib = CategoricalHMM(n_components=3, n_iter=500, tol=1e-9, init_params="", params="ste")
lib.startprob_, lib.transmat_, lib.emissionprob_ = pi_i.copy(), A_i.copy(), B_i.copy()
lib.fit(o.reshape(-1, 1))
print(f"Baum-Welch: logL propio {propio.loglik(o):.6f} | hmmlearn {lib.score(o.reshape(-1, 1)):.6f}")
print(f"            max|A_propio - A_hmmlearn| = {np.abs(propio.A - lib.transmat_).max():.2e}")
print(f"            max|B_propio - B_hmmlearn| = {np.abs(propio.B - lib.emissionprob_).max():.2e}")
print(f"            iteraciones propias = {info['iter']}, convergio = {info['convergio']}")
print("            logL crece monotonamente:",
      bool(np.all(np.diff(info['loglik_hist']) > -1e-8)))
p = mejor_permutacion(propio.A, propio.B, A0, B0)
print("Permutacion de estados hacia el modelo real:", p)
print("A estimada (reordenada):\n", np.round(propio.A[np.ix_(p, p)], 3))
print("B estimada (reordenada):\n", np.round(propio.B[p], 3))
