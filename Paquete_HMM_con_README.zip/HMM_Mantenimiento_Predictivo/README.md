# HMM para mantenimiento predictivo — Proyecto universitario

## Descripción
Implementación y experimentación de un Modelo Oculto de Markov (HMM) para representar,
en un escenario **sintético**, la condición de una máquina rotativa a partir de
observaciones discretas de vibración.

Estados ocultos: `Normal`, `Degradado`, `Falla`.
Observaciones: vibración `Baja`, `Media`, `Alta`.

> **Alcance:** los datos son simulados. Los resultados no constituyen validación
> industrial ni diagnóstico de una máquina real.

## Contenido del proyecto
- `hmm.py`: definición/operaciones del HMM y algoritmos.
- `validacion.py`: pruebas o validaciones del modelo.
- `simulacion.py`: experimento principal.
- `analisis.py`: análisis de resultados del experimento principal.
- `simulacion_convergencia.py`: experimento complementario de convergencia.
- `analisis_convergencia.py`: análisis de convergencia.
- `resultados/`: archivos de resultados (CSV) y figuras generadas/disponibles.

## Requisitos
Python 3.x y paquetes:
- numpy
- pandas
- matplotlib
- scipy
- hmmlearn (usado por la validación, si aplica)

Instalación recomendada:
```bash
python -m pip install numpy pandas matplotlib scipy hmmlearn
```

## Ejecución
Abra una terminal en la carpeta del proyecto y ejecute:

```bash
python validacion.py
python simulacion.py
python analisis.py
```

Experimento complementario:
```bash
python simulacion_convergencia.py
python analisis_convergencia.py
```

Ejecute los scripts en ese orden para que el análisis encuentre los resultados
producidos por la simulación. Los scripts pueden crear o actualizar archivos
dentro de `resultados/`.

## Diseño experimental (resumen)
- Ruido de emisión: ε ∈ {0, 0.3, 0.6}.
- Longitud de secuencia: T ∈ {100, 500, 1000}.
- Experimento principal: 30 réplicas por escenario y 10 inicializaciones de
  Baum–Welch por réplica; límite principal de iteraciones: 200.
- Experimento de convergencia: T = 1000, 10 réplicas por nivel de ε y límite
  ampliado de 1000 iteraciones.
- Semilla global documentada en el código: `SEED_GLOBAL = 2026` (o equivalente).

## Reproducibilidad y entorno
Para registrar el entorno donde se ejecuta:
```bash
python --version
python -m pip freeze > requirements-lock.txt
```
El archivo `requirements-lock.txt` debe generarse en el equipo de ejecución,
pues las versiones instaladas pueden variar. Para una reproducción rigurosa,
conserve también la salida de consola y los CSV generados.

## Interpretación de métricas
El decodificador-oráculo utiliza los parámetros generadores conocidos; es una
referencia experimental y **no** una configuración disponible en una aplicación
real. La estimación Baum–Welch depende de inicialización y convergencia.
No interprete réplicas o inicializaciones anidadas como observaciones
independientes.

## Licencia y uso
Material preparado para uso académico. No se especifica una licencia de
redistribución en los archivos originales.
