"""analisis_convergencia.py - Compara max_iter=200 vs 1000 (T=1000, replicas 0-9, pareado)."""
import numpy as np, pandas as pd
from scipy import stats
R = "resultados"
a = pd.read_csv(f"{R}/replicas.csv"); a = a[(a["T"] == 1000) & (a["rep"] < 10)]
b = pd.read_csv(f"{R}/convergencia_replicas.csv")
ib = pd.read_csv(f"{R}/convergencia_inicializaciones.csv")
ia = pd.read_csv(f"{R}/inicializaciones.csv"); ia = ia[(ia["T"] == 1000) & (ia["rep"] < 10)]
m = a.merge(b, on=["eps", "rep"], suffixes=("_200", "_1000"))
out = ["CONTROL DE CONVERGENCIA: T=1000, 10 replicas por eps, pareado por semilla\n"]
for eps, g in m.groupby("eps"):
    out.append(f"eps={eps}")
    for col in ["acc_bw", "err_A", "err_B", "frac_optimo", "frac_convergio"]:
        x, y = g[f"{col}_200"], g[f"{col}_1000"]
        try: p = stats.wilcoxon(x, y).pvalue
        except ValueError: p = np.nan
        out.append(f"   {col:15s} 200it: {x.mean():.3f}±{x.std(ddof=1):.3f} | 1000it: {y.mean():.3f}±{y.std(ddof=1):.3f} | Wilcoxon p={p:.3g}")
    out.append(f"   iteraciones medias (1000it): {g['iter_media_1000'].mean():.0f}")
    out.append(f"   brecha logL optimo-vs-verdadero (1000it): {(g['ll_mejor_1000']-g['ll_verdadero_1000']).mean():+.2f}")
    out.append(f"   n. de optimos distintos por replica: 200it {g['n_optimos_distintos_200'].mean():.1f} | 1000it {g['n_optimos_distintos_1000'].mean():.1f}\n")
out.append("Distribucion de inits (1000 it): fraccion que convergio por eps")
out.append(ib.groupby("eps")["convergio"].mean().round(3).to_string())
out.append("\nAccuracy BW por init (1000 it): media, sd entre inits dentro de replica, por eps")
out.append(ib.groupby(["eps","rep"])["acc_bw"].std().groupby("eps").mean().round(3).to_string())
open(f"{R}/convergencia_pruebas.txt", "w").write("\n".join(out)); print("\n".join(out))
