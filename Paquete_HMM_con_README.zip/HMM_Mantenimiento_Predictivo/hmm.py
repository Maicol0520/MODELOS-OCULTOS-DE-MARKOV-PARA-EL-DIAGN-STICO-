"""
hmm.py - HMM discreto implementado desde cero con NumPy.

Modelo lambda = (A, B, pi):
    A[i, j]  = P(q_{t+1} = s_j | q_t = s_i)      (N x N)
    B[j, k]  = P(o_t = v_k | q_t = s_j)          (N x M)
    pi[i]    = P(q_1 = s_i)                      (N,)

Algoritmos (con escalado numerico de Rabiner, 1989):
    forward / backward, viterbi (en log), baum_welch (EM).
"""
from __future__ import annotations

from dataclasses import dataclass, field
from itertools import permutations

import numpy as np

ESTADOS = ["Normal", "Degradado", "Falla"]
OBSERVACIONES = ["Baja", "Media", "Alta"]

# ---------------------------------------------------------------- Modelo base
A0 = np.array([[0.95, 0.05, 0.00],
               [0.00, 0.90, 0.10],
               [0.30, 0.00, 0.70]])
B0 = np.array([[0.80, 0.15, 0.05],
               [0.20, 0.55, 0.25],
               [0.05, 0.25, 0.70]])
PI0 = np.array([0.90, 0.08, 0.02])


def ruido_B(B: np.ndarray, eps: float) -> np.ndarray:
    """B(eps) = (1-eps) B0 + eps * (1/M) 11^T  (mezcla con emision uniforme)."""
    M = B.shape[1]
    return (1.0 - eps) * B + eps * np.full_like(B, 1.0 / M)


def distribucion_estacionaria(A: np.ndarray) -> np.ndarray:
    """Resuelve pi A = pi, sum(pi) = 1 (vector propio izquierdo de valor propio 1)."""
    w, v = np.linalg.eig(A.T)
    i = np.argmin(np.abs(w - 1.0))
    p = np.real(v[:, i])
    return p / p.sum()


def inicializacion_dirichlet(N: int, M: int, rng: np.random.Generator, alpha: float = 1.0):
    """Inicializacion aleatoria (A, B, pi) con filas ~ Dirichlet(alpha)."""
    A = rng.dirichlet(np.full(N, alpha), size=N)
    B = rng.dirichlet(np.full(M, alpha), size=N)
    pi = rng.dirichlet(np.full(N, alpha))
    return A, B, pi


@dataclass
class HMM:
    A: np.ndarray
    B: np.ndarray
    pi: np.ndarray
    N: int = field(init=False)
    M: int = field(init=False)

    def __post_init__(self):
        self.A = np.asarray(self.A, dtype=float).copy()
        self.B = np.asarray(self.B, dtype=float).copy()
        self.pi = np.asarray(self.pi, dtype=float).copy()
        self.N, self.M = self.B.shape
        self.validar()

    def validar(self, tol: float = 1e-8):
        assert self.A.shape == (self.N, self.N), "A debe ser N x N"
        assert self.pi.shape == (self.N,), "pi debe tener longitud N"
        for nombre, X in (("A", self.A), ("B", self.B)):
            assert np.all(X >= 0), f"{nombre} tiene entradas negativas"
            assert np.allclose(X.sum(axis=1), 1.0, atol=tol), f"filas de {nombre} no suman 1"
        assert np.all(self.pi >= 0) and abs(self.pi.sum() - 1.0) < tol, "pi invalido"

    # ------------------------------------------------------------ Simulacion
    def simular(self, T: int, rng: np.random.Generator):
        """Genera (estados, observaciones) de longitud T."""
        q = np.empty(T, dtype=int)
        o = np.empty(T, dtype=int)
        q[0] = rng.choice(self.N, p=self.pi)
        o[0] = rng.choice(self.M, p=self.B[q[0]])
        for t in range(1, T):
            q[t] = rng.choice(self.N, p=self.A[q[t - 1]])
            o[t] = rng.choice(self.M, p=self.B[q[t]])
        return q, o

    # --------------------------------------------------------------- Forward
    def forward(self, obs):
        """Forward escalado. Devuelve (alpha_hat, c, loglik)."""
        obs = np.asarray(obs)
        T = len(obs)
        alpha = np.zeros((T, self.N))
        c = np.zeros(T)
        a = self.pi * self.B[:, obs[0]]
        c[0] = a.sum()
        alpha[0] = a / c[0]
        for t in range(1, T):
            a = (alpha[t - 1] @ self.A) * self.B[:, obs[t]]
            c[t] = a.sum()
            alpha[t] = a / c[t]
        return alpha, c, float(np.log(c).sum())

    def loglik(self, obs) -> float:
        return self.forward(obs)[2]

    # -------------------------------------------------------------- Backward
    def backward(self, obs, c):
        """Backward escalado con los mismos factores c del forward."""
        obs = np.asarray(obs)
        T = len(obs)
        beta = np.zeros((T, self.N))
        beta[-1] = 1.0
        for t in range(T - 2, -1, -1):
            beta[t] = (self.A @ (self.B[:, obs[t + 1]] * beta[t + 1])) / c[t + 1]
        return beta

    # --------------------------------------------------------------- Viterbi
    def viterbi(self, obs):
        """Secuencia de estados mas probable (en log para evitar underflow)."""
        obs = np.asarray(obs)
        T = len(obs)
        with np.errstate(divide="ignore"):
            logA, logB, logpi = np.log(self.A), np.log(self.B), np.log(self.pi)
        delta = np.zeros((T, self.N))
        psi = np.zeros((T, self.N), dtype=int)
        delta[0] = logpi + logB[:, obs[0]]
        for t in range(1, T):
            cand = delta[t - 1][:, None] + logA          # (i, j)
            psi[t] = np.argmax(cand, axis=0)
            delta[t] = cand[psi[t], np.arange(self.N)] + logB[:, obs[t]]
        path = np.zeros(T, dtype=int)
        path[-1] = np.argmax(delta[-1])
        for t in range(T - 2, -1, -1):
            path[t] = psi[t + 1, path[t + 1]]
        return path, float(delta[-1].max())

    # ------------------------------------------------------------ Baum-Welch
    def baum_welch(self, obs, max_iter: int = 200, tol: float = 1e-6, suavizado: float = 1e-12):
        """
        EM de Baum-Welch (modifica el modelo in situ).
        Devuelve dict con historial de log-verosimilitud, iteraciones y convergencia.
        """
        obs = np.asarray(obs)
        T = len(obs)
        hist = []
        convergio = False
        for it in range(1, max_iter + 1):
            alpha, c, ll = self.forward(obs)
            beta = self.backward(obs, c)
            hist.append(ll)

            # E-step
            gamma = alpha * beta
            gamma /= gamma.sum(axis=1, keepdims=True)
            # xi_t(i,j) vectorizado: alpha_t(i) A_ij b_j(o_{t+1}) beta_{t+1}(j) / c_{t+1}
            W = (self.B[:, obs[1:]].T * beta[1:]) / c[1:, None]
            xi_sum = self.A * (alpha[:-1].T @ W)

            # M-step
            self.pi = gamma[0] + suavizado
            self.pi /= self.pi.sum()
            self.A = xi_sum + suavizado
            self.A /= self.A.sum(axis=1, keepdims=True)
            Bn = np.full((self.N, self.M), suavizado)
            for k in range(self.M):
                Bn[:, k] += gamma[obs == k].sum(axis=0)
            self.B = Bn / Bn.sum(axis=1, keepdims=True)

            if it > 1 and abs(hist[-1] - hist[-2]) < tol:
                convergio = True
                break
        hist.append(self.loglik(obs))
        return {"loglik_hist": np.array(hist), "iter": it, "convergio": convergio}


# ------------------------------------------------------- Utilidades de analisis
def mejor_permutacion(A_est, B_est, A_ref, B_ref):
    """
    Baum-Welch es identificable solo salvo permutacion de estados.
    Busca la permutacion que minimiza el error de Frobenius en A y B.
    """
    N = A_ref.shape[0]
    mejor, err_min = None, np.inf
    for p in permutations(range(N)):
        p = list(p)
        err = np.linalg.norm(A_est[np.ix_(p, p)] - A_ref) + np.linalg.norm(B_est[p] - B_ref)
        if err < err_min:
            mejor, err_min = p, err
    return mejor


def exactitud(q_real, q_est) -> float:
    return float(np.mean(np.asarray(q_real) == np.asarray(q_est)))
