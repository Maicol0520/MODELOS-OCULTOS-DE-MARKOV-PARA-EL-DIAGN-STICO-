"""
analisis.py - Estadisticos, pruebas y figuras (F6).
Entradas : resultados/replicas.csv, resultados/inicializaciones.csv
Salidas  : resultados/tabla_estadisticos.csv, tabla_estadisticos.md, pruebas.txt,
           figuras/fig1_exactitud.png, fig2_estimacion.png, fig3_inicializacion.png
Ejecutar:  python analisis.py
"""
import os

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from scipy import stats

R = "resultados"
os.makedirs(f"{R}/figuras", exist_ok=True)
rep = pd.read_csv(f"{R}/replicas.csv")
ini = pd.read_csv(f"{R}/inicializaciones.csv")

plt.rcParams.update({"font.size": 10, "axes.grid": True, "grid.alpha": 0.3,
                     "axes.spines.top": False, "axes.spines.right": False})
COL = {0.0: "#2a9d8f", 0.3: "#e9a03b", 0.6: "#c0392b"}
ETQ = {0.0: "ε = 0.0 (limpio)", 0.3: "ε = 0.3 (medio)", 0.6: "ε = 0.6 (alto)"}


def ic95(x):
    x = np.asarray(x, dtype=float)
    n = len(x)
    m, s = x.mean(), x.std(ddof=1)
    h = stats.t.ppf(0.975, n - 1) * s / np.sqrt(n)
    return m - h, m + h


# ------------------------------------------------------------------ Tabla
METRICAS = {
    "acc_oraculo": "Exactitud Viterbi (modelo verdadero)",
    "acc_bw": "Exactitud Viterbi (Baum-Welch)",
    "acc_ingenuo": "Exactitud regla ingenua",
    "err_A": "Error ||Â-A||_F",
    "err_B": "Error ||B̂-B||_F",
    "iter_mejor": "Iteraciones (mejor init)",
    "frac_optimo": "Fracción de inits en el mejor óptimo",
}
filas = []
for (eps, T), g in rep.groupby(["eps", "T"]):
    for col, nombre in METRICAS.items():
        lo, hi = ic95(g[col])
        filas.append(dict(eps=eps, T=T, metrica=nombre, media=g[col].mean(),
                          sd=g[col].std(ddof=1), min=g[col].min(), max=g[col].max(),
                          ic_inf=lo, ic_sup=hi, n=len(g)))
tab = pd.DataFrame(filas)
tab.to_csv(f"{R}/tabla_estadisticos.csv", index=False)

# Tabla compacta (media ± sd [IC]) para el articulo
comp = []
for (eps, T), g in rep.groupby(["eps", "T"]):
    fila = {"ε": eps, "T": T}
    for col, nom in [("acc_oraculo", "Acc. oráculo"), ("acc_bw", "Acc. BW"),
                     ("err_A", "Error A"), ("err_B", "Error B"), ("frac_optimo", "Frac. óptimo")]:
        lo, hi = ic95(g[col])
        fila[nom] = f"{g[col].mean():.3f} ± {g[col].std(ddof=1):.3f} [{lo:.3f}, {hi:.3f}]"
    comp.append(fila)
comp = pd.DataFrame(comp)
comp.to_csv(f"{R}/tabla_compacta.csv", index=False)
with open(f"{R}/tabla_compacta.md", "w") as f:
    f.write(comp.to_markdown(index=False))

# ----------------------------------------------------------------- Pruebas
out = []
out.append("PRUEBAS ESTADISTICAS (alfa = 0.05)\n")
out.append("1) Efecto de eps sobre la exactitud de Viterbi-oraculo (Kruskal-Wallis, por T):")
for T, g in rep.groupby("T"):
    H, p = stats.kruskal(*[x["acc_oraculo"].values for _, x in g.groupby("eps")])
    out.append(f"   T={T}: H={H:.2f}, p={p:.2e}")
out.append("\n2) Efecto de T sobre el error de A (Kruskal-Wallis, por eps):")
for eps, g in rep.groupby("eps"):
    H, p = stats.kruskal(*[x["err_A"].values for _, x in g.groupby("T")])
    out.append(f"   eps={eps}: H={H:.2f}, p={p:.2e}")
out.append("\n3) Efecto de T sobre el error de B (Kruskal-Wallis, por eps):")
for eps, g in rep.groupby("eps"):
    H, p = stats.kruskal(*[x["err_B"].values for _, x in g.groupby("T")])
    out.append(f"   eps={eps}: H={H:.2f}, p={p:.2e}")
out.append("\n4) Oraculo vs Baum-Welch (Wilcoxon pareado, por escenario): brecha media = acc_oraculo - acc_bw")
for (eps, T), g in rep.groupby(["eps", "T"]):
    d = g["acc_oraculo"] - g["acc_bw"]
    try:
        W, p = stats.wilcoxon(d)
    except ValueError:
        W, p = np.nan, np.nan
    out.append(f"   eps={eps}, T={T}: brecha={d.mean():+.4f}, p={p:.2e}")
out.append("\n5) Viterbi-oraculo vs regla ingenua (Wilcoxon pareado, por escenario):")
for (eps, T), g in rep.groupby(["eps", "T"]):
    d = g["acc_oraculo"] - g["acc_ingenuo"]
    try:
        W, p = stats.wilcoxon(d)
    except ValueError:
        W, p = np.nan, np.nan
    out.append(f"   eps={eps}, T={T}: ganancia={d.mean():+.4f}, p={p:.2e}")
out.append("\n6) Correlacion de Spearman (replicas, n=270):")
for a, b in [("T", "err_A"), ("T", "err_B"), ("eps", "acc_oraculo"), ("eps", "err_B"),
             ("eps", "frac_optimo"), ("T", "frac_optimo")]:
    rho, p = stats.spearmanr(rep[a], rep[b])
    out.append(f"   {a} vs {b}: rho={rho:+.3f}, p={p:.2e}")
open(f"{R}/pruebas.txt", "w").write("\n".join(out))

# ------------------------------------------------------------------ Fig 1
fig, ax = plt.subplots(1, 2, figsize=(9, 3.8), sharey=True)
Ts = sorted(rep["T"].unique())
for a, col, tit in [(ax[0], "acc_oraculo", "(a) Viterbi con el modelo verdadero"),
                    (ax[1], "acc_bw", "(b) Viterbi con modelo aprendido (Baum-Welch)")]:
    for eps in sorted(rep["eps"].unique()):
        m, lo, hi = [], [], []
        for T in Ts:
            x = rep[(rep.eps == eps) & (rep["T"] == T)][col]
            l, h = ic95(x)
            m.append(x.mean()); lo.append(l); hi.append(h)
        m, lo, hi = map(np.array, (m, lo, hi))
        a.errorbar(Ts, m, yerr=[m - lo, hi - m], marker="o", capsize=3,
                   color=COL[eps], label=ETQ[eps])
    base = rep.groupby("eps")["acc_ingenuo"].mean()
    a.set_xscale("log"); a.set_xticks(Ts); a.set_xticklabels(Ts)
    a.set_xlabel("Longitud de la secuencia T"); a.set_title(tit, fontsize=10)
axx = ax[0]; axx.set_ylabel("Exactitud de decodificación (media e IC 95 %)")
ax[0].legend(frameon=False, loc="lower left")
plt.tight_layout(); plt.savefig(f"{R}/figuras/fig1_exactitud.png", dpi=300); plt.close()

# ------------------------------------------------------------------ Fig 2
fig, ax = plt.subplots(1, 2, figsize=(9, 3.8))
for a, col, tit, yl in [(ax[0], "err_A", "(a) Error de estimación de A", r"$\|\hat{A}-A\|_F$"),
                        (ax[1], "err_B", "(b) Error de estimación de B", r"$\|\hat{B}-B(\varepsilon)\|_F$")]:
    ancho = 0.25
    for j, eps in enumerate(sorted(rep["eps"].unique())):
        datos = [rep[(rep.eps == eps) & (rep["T"] == T)][col].values for T in Ts]
        pos = np.arange(len(Ts)) + (j - 1) * ancho
        bp = a.boxplot(datos, positions=pos, widths=ancho * 0.85, patch_artist=True,
                       showfliers=False, medianprops=dict(color="black"))
        for b in bp["boxes"]:
            b.set_facecolor(COL[eps]); b.set_alpha(0.75)
    a.set_xticks(range(len(Ts))); a.set_xticklabels(Ts)
    a.set_xlabel("Longitud de la secuencia T"); a.set_ylabel(yl); a.set_title(tit, fontsize=10)
handles = [plt.Rectangle((0, 0), 1, 1, fc=COL[e], alpha=0.75) for e in sorted(COL)]
ax[1].legend(handles, [ETQ[e] for e in sorted(COL)], frameon=False, loc="upper right")
plt.tight_layout(); plt.savefig(f"{R}/figuras/fig2_estimacion.png", dpi=300); plt.close()

# ------------------------------------------------------------------ Fig 3
fig, ax = plt.subplots(1, 2, figsize=(9, 3.8))
for eps in sorted(rep["eps"].unique()):
    m, lo, hi = [], [], []
    for T in Ts:
        x = rep[(rep.eps == eps) & (rep["T"] == T)]["frac_optimo"]
        l, h = ic95(x); m.append(x.mean()); lo.append(l); hi.append(h)
    m, lo, hi = map(np.array, (m, lo, hi))
    ax[0].errorbar(Ts, m, yerr=[m - lo, hi - m], marker="s", capsize=3,
                   color=COL[eps], label=ETQ[eps])
ax[0].set_xscale("log"); ax[0].set_xticks(Ts); ax[0].set_xticklabels(Ts)
ax[0].set_xlabel("Longitud de la secuencia T")
ax[0].set_ylabel("Fracción de inicializaciones\nque alcanzan el mejor óptimo")
ax[0].set_title("(a) Éxito de la inicialización", fontsize=10); ax[0].legend(frameon=False)

g = ini[(ini["T"] == 1000)]
datos = [g[g.eps == eps]["loglik"].values - g[g.eps == eps].groupby("rep")["loglik"].transform("max").values
         for eps in sorted(rep["eps"].unique())]
bp = ax[1].boxplot(datos, patch_artist=True, showfliers=True, medianprops=dict(color="black"),
                   flierprops=dict(marker=".", markersize=3, alpha=0.5))
for b, eps in zip(bp["boxes"], sorted(COL)):
    b.set_facecolor(COL[eps]); b.set_alpha(0.75)
ax[1].set_xticklabels([f"ε = {e}" for e in sorted(COL)])
ax[1].set_ylabel("logL − logL del mejor óptimo\n(por réplica, T = 1000)")
ax[1].set_title("(b) Brecha de verosimilitud entre inicializaciones", fontsize=10)
plt.tight_layout(); plt.savefig(f"{R}/figuras/fig3_inicializacion.png", dpi=300); plt.close()

print(comp.to_string(index=False))
print("\n" + "\n".join(out))
